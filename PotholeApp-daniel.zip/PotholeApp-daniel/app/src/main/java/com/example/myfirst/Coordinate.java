package com.example.myfirst;

public class Coordinate {
        public double latitude;
        public double longitude;
}
