package com.example.myfirst;

import android.app.AlertDialog;
import android.database.Cursor;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.QuickContactBadge;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.myfirst.android.app.Accelerometer;
import com.example.myfirst.android.app.DataBaseHelper;
import com.example.myfirst.android.app.GPS;
import com.example.myfirst.android.app.Search;


public class MainActivity extends AppCompatActivity {

    private LocationListener locationListener;
    private Button viewData, start, updateThresh;
    private TextView threshText;
    private SeekBar seekBar;
    private LocationManager locationManager;
    private GPS gps;
    private Accelerometer accelerometer;
    private boolean mLocationPermissionGranted;
    private DataBaseHelper database;
    private Search search;
    private MediaPlayer mediaPlayer;
    private EditText threshold;

    private Accelerometer acc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final ImageView mainBackground = (ImageView)findViewById(R.id.image);
        gps = new GPS(this, this);



        // Set up tool bar for UI
       // Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
       // setSupportActionBar(myToolbar);

        //gps set up
        gps = new GPS(this, this, resultsText);
        gps.gpsSstup();
        database = new DataBaseHelper(this);
        accelerometer = new Accelerometer(this);
        mediaPlayer = MediaPlayer.create(this, R.raw.beep);
        search = new Search(database, gps, accelerometer, mediaPlayer);

        // accelerometer set up
        SensorManager sensoryManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor accelerometer = sensoryManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        acc = new Accelerometer(sensoryManager, accelerometer);


        // get the button from the activity view, using the ID: rollButton
        threshText = findViewById(R.id.threshText);
        start = findViewById(R.id.Startbutton);
        threshold = findViewById(R.id.thresh);
        viewData = findViewById(R.id.viewData);
        updateThresh = findViewById(R.id.update);
        search.start();

        // setup the background image
        mainBackground.setImageResource(R.drawable.app2);

        // setting up the location manager


        configureButton();
        viewAll();

    }

    // method which setups the view button
    public void viewAll() {
        viewData.setOnClickListener(
                new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = database.getAllData();

                        if(res.getCount() == 0) {
                            // show error
                            return;
                        }
                        else {
                            StringBuffer buffer = new StringBuffer();

                            while( res.moveToNext()) {
                                buffer.append("ID :" + res.getString(0) + "\n");
                                buffer.append("DATA :" + res.getString(1) + "\n");
                                buffer.append(("DATA2 : " + res.getString(2) + "\n"));
                            }

                            showMessage("dData", buffer.toString());
                        }
                    }
                }
        );
    }

    public void clearData() {

        try {
        database.clearData(); }
        catch(Exception R) {
            R.printStackTrace();
        }
    }

    //method called to display the database results in a popup window
    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        gps.onResults(requestCode, permissions, grantResults);
    }

    private void configureButton() {

        updateThresh.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                float data = Float.valueOf(threshold.getText().toString());
                accelerometer.setTresh(data);
                threshText.setText(threshold.getText());
            }



        });



        start.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                clearData();

            }
        }
        );




    }



}
