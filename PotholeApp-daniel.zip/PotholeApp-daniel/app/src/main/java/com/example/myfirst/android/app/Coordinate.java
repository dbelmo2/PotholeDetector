package com.example.myfirst.android.app;

public class Coordinate {

    public double latitude;
    public double longitude;



    Coordinate(double latitude, double longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }
}
