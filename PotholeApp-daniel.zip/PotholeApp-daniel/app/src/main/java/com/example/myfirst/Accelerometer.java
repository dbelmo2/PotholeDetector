package com.example.myfirst;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class Accelerometer extends AppCompatActivity implements SensorEventListener {
    private static final String TAG = "MainActivity";
    private float previousZ = 0.0f;
    private SensorManager sensoryManager;
    Sensor accelerometer;
    private boolean potholeHit = false;

    Accelerometer(SensorManager sensorManager, Sensor accelerometer) {
        Log.d(TAG, "onCreate: Initializing Sensor Services");
        this.sensoryManager = sensorManager;
        this. accelerometer = accelerometer;
        sensoryManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        Log.d(TAG, "onCreate: Registered accelerometer listener");
    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        float zAxis = sensorEvent.values[2];
        float threshold = 3.0f;


        Log.d(TAG, "previous Z " + previousZ );
        Log.d(TAG, "new Z " + zAxis);

        float difference = Math.abs(previousZ - zAxis);


        // function call to compare two float values
        if (Float.compare(difference, threshold) == 0) {

            System.out.println("pothole hit");
            potholeHit = true;
        }
        else if (Float.compare(difference, threshold) < 0) {

            System.out.println("Just a bump");
            potholeHit = false;
        }
        else {

            System.out.println("pothole hit");
            potholeHit = true;
        }

        previousZ = zAxis;
    }

    public boolean getBoolean() {
        return potholeHit;
    }

}
