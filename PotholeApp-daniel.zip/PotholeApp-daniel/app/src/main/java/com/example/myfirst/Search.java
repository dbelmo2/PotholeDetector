package com.example.myfirst;
import android.content.Context;


public class Search extends Thread {
    private double pLat, pLong;
    private DataBaseHelper database;
    GPS gps;
    private boolean potHoleFound = false;
    private Coordinate CurrentCoordinate;


    Search(DataBaseHelper dataBase, GPS gps) {
        this.database = dataBase;
        this.gps = gps;
    }

    public void run() {

        try {

            while (true) {
                this.sleep(500);

                gps.requestLoc();
                // get coordinate at current time
                CurrentCoordinate.latitude = gps.getLatitude();
                CurrentCoordinate.longitude = gps.getLongitude();
                potHoleFound = database.checkCoordinate(CurrentCoordinate);

                if(potHoleFound) {

                    potHoleFound = false;
                }


            }
        }catch(Exception A) {
            A.printStackTrace();
        }


    }

    public void setPotHoleFound(boolean state) {
        this.potHoleFound = state;
    }




}
